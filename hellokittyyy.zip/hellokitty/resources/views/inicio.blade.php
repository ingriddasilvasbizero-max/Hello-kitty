
<!doctype html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Escolha seu personagem - Mapadev Week</title>

    <link rel="stylesheet" href="{{ asset('css/variaveis.css') }}">
    <link rel="stylesheet" href="{{ asset('css/reset.css') }}">
    <link rel="stylesheet" href="{{ asset('css/fontes.css') }}">
    <link rel="stylesheet" href="{{ asset('css/animacoes.css') }}">
    <link rel="stylesheet" href="{{ asset('css/estilos.css') }}">
    <link rel="stylesheet" href="{{ asset('css/responsivo.css') }}">
    </head>
    <body>
        <main>
            <header class="cabecalho">
                <h1 class="titulo">Character select</h1>
            </header>
            <div class="selecao-de-personagens">
                <div class="personagem-grande personagem-jogador-1">
                    <img src="{{ asset ('img/cinnamon2.webp') }}" alt="personagem selecionado jogador 1" id="personagem-jogador-1">
                    <div class="nome">
                        <h2 id="nome-jogador-1">Cinnamoroll</h2>
                    </div>
                </div>
                    <ul class="lista-de-personagens">
                        <li class="personagem selecionado" id="personagem-jogador-1" data-name="Cinnamoroll">
                            <span class="tag">1P</span>
                            <img src="{{ asset('img/cinnamoroll.png') }}" alt="Personagem Cinnamoroll">
                        </li>

                        <li class="personagem" id="personagem-jogador-1" data-name="Hello Kitty">
                            <span class="tag">1P</span>
                            <img src="{{ asset ('img/hellokitty.png') }}" alt="Personagem Hello Kitty">
                        </li>

                        <li class="personagem" id="personagem-jogador-1" data-name="Kuromi">
                            <span class="tag">1P</span>
                            <img src="{{ asset ('img/kuromi.png') }}" alt="Personagem Kuromi">
                        </li>

                        <li class="personagem" id="personagem-jogador-1" data-name="My Melody">
                            <span class="tag">1P</span>
                            <img src="{{ asset ('img/mymelody.png') }}" alt="Personagem My Melody">
                        </li>

                        <li class="personagem" id="personagem-jogador-1" data-name="Badtz-Maru">
                            <span class="tag">1P</span>
                            <img src="{{ asset ('img/pinguin.jpg') }}" alt="Personagem Badtz-Maru">
                        </li>

                        <li class="personagem jogador-2-selecionado" id="pompompurin" data-name="Pompompurin">
                            <span class="tag">2P</span>
                            <img src="{{ asset ('img/pompom.jpg') }}" alt="Personagem Pompompurin">
                        </li>

                        <li class="personagem" id="personagem-jogador-1" data-name="Keroppi">
                            <span class="tag">1P</span>
                            <img src="{{ asset ('img/sapo.png') }}" alt="Personagem Keroppi">
                        </li>

                        <li class="personagem" id="personagem-jogador-1" data-name="Chococat">
                            <span class="tag">1P</span>
                            <img src="{{ asset ('img/gato.png') }}" alt="Personagem Chococat">
            
                        <li class="personagem" id="Pocchaco" data-name="Pocchaco">
                            <span class="tag">1P</span>
                            <img src="{{ asset ('img/pocchaco.png') }}" alt="Personagem Pocchaco">
                        </li>
                    </ul>
                <div class="personagem-grande personagem-jogador-2">
                    <img src="{{ asset ('img/pompom2.png') }}" alt="personagem selecionado jogador 2" id="personagem-jogador-2">
                    <div class="nome">
                        <h2>Pompompurin</h2>
                    </div>

                </div>
            </div>
        </main>

        <script src="{{ asset('js/index.js') }}"></script>
    </body>
</html>