<!doctype html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Escolha seu personagem - Mapadev Week</title>

    <link rel="stylesheet" href="<?php echo e(asset('css/variaveis.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/reset.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fontes.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/animacoes.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/estilos.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/responsivo.css')); ?>">
    </head>
    <body>
        <main>
            <header class="cabecalho">
                <h1 class="titulo">Character select</h1>
            </header>
            <div class="selecao-de-personagens">
                <div class="personagem-grande personagem-jogador-1">
                    <img src="src/images/thor.png" alt="personagem selecionado jogador 1" id="personagem-jogador-1">
                    <div class="nome">
                        <h2 id="nome-jogador-1">Thor</h2>
                    </div>
                </div>
                    <ul class="lista-de-personagens">
                        <li class="personagem selecionado" id="thor" data-name="Thor">
                            <span class="tag">1P</span>
                            <img src="<?php echo e(asset('img/thor.png')); ?>" alt="Personagem Thor">
                        </li>

                        <li class="personagem" id="homem-de-ferro" data-name="Homem de ferro">
                            <span class="tag">1P</span>
                            <img src="<?php echo e(asset ('img/homem-de-ferro.jpg')); ?>" alt="Personagem Homem de ferro">
                        </li>

                        <li class="personagem" id="viuva-negra" data-name="Viúva Negra">
                            <span class="tag">1P</span>
                            <img src="src/images/viuva-negra.jpg" alt="Personagem Viúva Negra">
                        </li>

                        <li class="personagem" id="hulk" data-name="Hulk">
                            <span class="tag">1P</span>
                            <img src="src/images/hulk.jpg" alt="Personagem Hulk">
                        </li>

                        <li class="personagem" id="capitao-america" data-name="Capitão América">
                            <span class="tag">1P</span>
                            <img src="src/images/capitao-america.jpg" alt="Personagem Capitão América">
                        </li>

                        <li class="personagem jogador-2-selecionado" id="ultron" data-name="Ultron">
                            <span class="tag">2P</span>
                            <img src="src/images/ultron.jpg" alt="Personagem Ultron">
                        </li>

                        <li class="personagem" id="doutor-doom" data-name="Doutor Doom">
                            <span class="tag">1P</span>
                            <img src="src/images/doutor-doom.jpg" alt="Personagem Doutor Doom">
                        </li>

                        <li class="personagem" id="nova" data-name="Nova">
                            <span class="tag">1P</span>
                            <img src="src/images/nova.jpg" alt="Personagem Nova">
                        </li>

                        <li class="personagem" id="fenix" data-name="Fênix">
                            <span class="tag">1P</span>
                            <img src="src/images/fenix.jpg" alt="Personagem Fênix">
                        </li>
                    </ul>
                <div class="personagem-grande personagem-jogador-2">
                    <img src="src/images/ultron.png" alt="personagem selecionado jogador 2" id="personagem-jogador-2">
                    <div class="nome">
                        <h2>Ultron</h2>
                    </div>
                </div>
            </div>
        </main>

        <script src="<?php echo e(asset('js/index.js')); ?>"></script>
    </body>
</html><?php /**PATH C:\xampp\htdocs\marvel\resources\views/inicio.blade.php ENDPATH**/ ?>